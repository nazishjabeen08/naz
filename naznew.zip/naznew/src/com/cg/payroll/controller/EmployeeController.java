package com.cg.payroll.controller;
import java.sql.SQLException;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.servlet.ModelAndView;

import com.cg.payroll.beans.Employee;
import com.cg.payroll.service.PayrollServices;

@Controller
public class EmployeeController {
	
	@Autowired
	PayrollServices payrollServices;
	

	@RequestMapping(value= "/addEmp")
	public String open(@ModelAttribute("emp") Employee emp) throws SQLException{
		
		return "addEmployee";
	}
	
	
	@RequestMapping(value= "/add", method = RequestMethod.POST)
	public ModelAndView insertEmployee(@ModelAttribute("emp") Employee emp) throws SQLException{
		int empId=payrollServices.insertEmployee(emp);
		return new ModelAndView("addSuccess","message",empId);
	}
	

	@RequestMapping(value = "/deleteEmp", method = RequestMethod.POST)
	public String close(@PathVariable int empId) {
		
		return "deleteEmployee";
	}
	
	@RequestMapping(value = "/delete", method = RequestMethod.POST)
	public ModelAndView deleteEmployee(@PathVariable int empId) throws SQLException {
		int employeeId=payrollServices.deleteEmployee(empId);
		return new ModelAndView("deleteSuccess","message",employeeId);
	}
}