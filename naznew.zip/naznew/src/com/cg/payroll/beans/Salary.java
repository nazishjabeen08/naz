package com.cg.payroll.beans;

import javax.persistence.Embeddable;

@Embeddable
public class Salary {
	
	private double basicSalary;
	private double hra,ta,da;
	private double companyPf=3480, employeePf=3480;
	private double grossSalary,monthlyTax,netSalary;
	
	public double getBasicSalary() {
		return basicSalary;
	}
	public void setBasicSalary(double basicSalary) {
		this.basicSalary = basicSalary;
	}
	@Override
	public String toString() {
		return "Salary [basicSalary=" + basicSalary + ", hra=" + hra + ", ta="
				+ ta + ", da=" + da + ", companyPf=" + companyPf
				+ ", employeePf=" + employeePf + ", grossSalary=" + grossSalary
				+ ", monthlyTax=" + monthlyTax + ", netSalary=" + netSalary
				+ "]";
	}
	

}
