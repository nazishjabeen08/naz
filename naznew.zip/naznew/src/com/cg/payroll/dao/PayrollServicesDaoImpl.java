package com.cg.payroll.dao;

import java.sql.SQLException;
import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;

import org.hibernate.SessionFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import com.cg.payroll.beans.Employee;
import com.cg.payroll.exceptions.PayrollServicesDownException;

@Repository("payrollDAOServices")
public class PayrollServicesDaoImpl implements PayrollDAOServices{

	@PersistenceContext
	EntityManager entityManager;

	@Override
	public int insertEmployee(Employee employee) throws SQLException {
		
		entityManager.persist(employee);
		entityManager.flush();
		return employee.getEmploeeId();
	}

	@Override
	public boolean updateEmployee(Employee employee) throws SQLException {
		// TODO Auto-generated method stub
		return false;
	}

	@Override
	public int deleteEmployee(int employeeId) throws SQLException {
		
		return employeeId;
	
	}

	@Override
	public Employee getEmployee(int employeeId) throws SQLException {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public List<Employee> getAllEmployees() throws SQLException {
		// TODO Auto-generated method stub
		return null;
	}

	

}
