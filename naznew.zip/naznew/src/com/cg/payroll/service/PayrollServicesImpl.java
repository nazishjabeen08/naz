package com.cg.payroll.service;

import java.sql.SQLException;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.cg.payroll.beans.Employee;
import com.cg.payroll.beans.Salary;
import com.cg.payroll.dao.PayrollDAOServices;
import com.cg.payroll.exceptions.EmployeeDetailsNotFoundException;
import com.cg.payroll.exceptions.PayrollServicesDownException;

@Service("payrollService")
public class PayrollServicesImpl implements PayrollServices {
	
	
	@Autowired
	private PayrollDAOServices payrollDAOServices;
	@Override
	public double calculateEmployeeNetSalary(int employeeId)
			throws EmployeeDetailsNotFoundException,
			PayrollServicesDownException {
		
		 Salary s=new Salary();
		double bs=s.getBasicSalary();
		double hra =  0.4*bs;
		double ta = 0.2*bs;
		double da = 0.25*bs;
		double companyPf = 3480;
		double employeePf=3480;
		double grossSalary = hra+ta+da+bs+companyPf+employeePf;
		double annualSalary=grossSalary*12;
		double tax = 0;
		if(annualSalary>=0 && annualSalary<=250000)
			tax=0;
				else if(annualSalary>250000 && annualSalary<=500000)
					tax=0.05*(bs-250000);
						else if(annualSalary>500000 && annualSalary<=1000000)
							tax=0.20*(annualSalary-500000)+0.05*250000;
								else if(annualSalary>1000000)
									tax=30*(bs-1000000)+0.20*500000+0.05*250000;
		
		
		double netSalary=annualSalary-tax-companyPf-employeePf;
		
		return netSalary;
	}

	@Override
	public Employee getEmployeeDetails(int employeeid)
			throws EmployeeDetailsNotFoundException,
			PayrollServicesDownException {
		 try {
			return payrollDAOServices.getEmployee(employeeid);
		} catch (SQLException e) {
			
			e.printStackTrace();
			return null;
		}
		
	
	}

	@Override
	public List<Employee> getAllEmployeeDetails()
			throws PayrollServicesDownException {
		try {
			return payrollDAOServices.getAllEmployees();
		} catch (SQLException e) {
			
			e.printStackTrace();
			return null;
		}
		
				
	}

	@Override
	public int deleteEmployee(int empId) throws SQLException {
		return payrollDAOServices.deleteEmployee(empId);
		
	}

	@Override
	public int insertEmployee(Employee employee) throws SQLException {
		
		return payrollDAOServices.insertEmployee(employee);
	}


}
