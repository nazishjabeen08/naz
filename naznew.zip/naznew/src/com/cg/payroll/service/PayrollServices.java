package com.cg.payroll.service;
import java.sql.SQLException;
import java.util.List;

import com.cg.payroll.beans.*;
import com.cg.payroll.exceptions.EmployeeDetailsNotFoundException;
import com.cg.payroll.exceptions.PayrollServicesDownException;


public interface PayrollServices {
	
	double calculateEmployeeNetSalary(int employeeId) throws EmployeeDetailsNotFoundException,PayrollServicesDownException;
	Employee getEmployeeDetails(int employeeid)throws EmployeeDetailsNotFoundException,PayrollServicesDownException;
	List<Employee> getAllEmployeeDetails()throws PayrollServicesDownException;
	int deleteEmployee(int empId) throws SQLException;
	int insertEmployee(Employee employee)throws SQLException;
}